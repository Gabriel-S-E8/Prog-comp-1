function exercicio0(){
    let soma = 0 // Valor que neutraliza a soma (0 não atrapalha a soma)

    let i = 1

    while (1 <= 10){
        let nota = Number(prompt(`Informe a nota`))

        soma = soma + nota

        i++
    }
    let media = soma / 10
    alert(`À média das notas é ${media}`)
}

function exercicio1(){

}

function exercicio2(){

    let qtde = 120
    let lucro
    let saida = "" //Varíavel acumuladora
    let ml = 0
    let mqt = 0
    let mp = 0 // preco que me dá maior lucro

    for(let preco = 5.0; preco >= 1.0; preco = preco - 0.50)
    {
        lucro = (preco * qtde) - 200
        if(lucro > ml) // encontramos um lucro maior que o ml
        {
            ml = lucro
            mqt = qtde
            mp = preco
        }
        saida = saida + `\nPreço: ${preco} qtde: ${preco} Despesas: 200 Lucro: ${lucro}`

        //Prepara para a proxima vez

        qtde = qtde + 26
    }
    alert(saida)
    alert(`Maior lucro ${ml} com qtde ${mqt} com preco ${mp}`)

}

function exercicio3(){

}

function exercicio4(){
    
}